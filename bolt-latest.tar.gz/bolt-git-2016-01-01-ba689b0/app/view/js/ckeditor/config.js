// CKeditor config is done in /app/src/js/bolt.min.js.
