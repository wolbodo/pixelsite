"Flat" Skin
====================

This skin is a modification from Moono without the radius-corner and gradients.
Keep all the structrue unchanged.

Dongxu Ren
03/17/2015
